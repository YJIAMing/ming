
var bookDataFromLocalStorage = [];

$(function(){
    loadBookData();
    
    var data = [/*加上VALUE */
        {text:"資料庫",value:1},
        {text:"網際網路",value:2},
        {text:"應用系統整合",value:3},
        {text:"家庭保健",value:4},
        {text:"語言",value:5}
    ]
    $("#book_category").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: data,
        index: 0,
        change: onChange
    });
 
    $("#bought_datepicker").kendoDatePicker();
    $("#book_grid").kendoGrid({
        dataSource: {
            data: bookDataFromLocalStorage,
            schema: {
                model: {
                    fields: {
                        BookId: {type:"int"},
                        BookName: { type: "string" },
                        BookCategory: { type: "string" },
                        BookAuthor: { type: "string" },
                        BookBoughtDate: { type: "string" }
                    }
                }
            },
            pageSize: 20,
        },
        toolbar: kendo.template("<div class='book-grid-toolbar'><input class='book-grid-search' placeholder='我想要找......' type='text'></input></div>"),
        height: 550,
        sortable: true,
        pageable: {
            input: true,
            numeric: false
        },
        columns: [
            { field: "BookId", title: "書籍編號",width:"10%"},
            { field: "BookName", title: "書籍名稱", width: "50%" },
            { field: "BookCategory", title: "書籍種類", width: "10%" },
            { field: "BookAuthor", title: "作者", width: "15%" },
            { field: "BookBoughtDate", title: "購買日期", width: "15%" },
            { command: {text: "刪除", click: deleteBook }, title: " ", width: "120px" }
        ]
        
    });
})

function loadBookData(){
    bookDataFromLocalStorage = JSON.parse(localStorage.getItem("bookData"));
    if(bookDataFromLocalStorage == null){
        bookDataFromLocalStorage = bookData;
        localStorage.setItem("bookData",JSON.stringify(bookDataFromLocalStorage));
    }
}


//變圖片
var selectedcategory = $("#book_category").val();
function onChange(){
    selectedcategory = $("#book_category").val();/*須設在裡面 才會每次變*/
    if(selectedcategory==1)
    {   
        $(".book-image").attr("src","image/"+database+".jpg"); //
    }
    else if(selectedcategory==2)
    {
        $(".book-image").attr("src","image/internet.jpg");
    }
    else if(selectedcategory==3)
    {
        $(".book-image").attr("src","image/system.jpg");
    }
    else if(selectedcategory==4)
    {
        $(".book-image").attr("src","image/home.jpg");
    }
    else
    {
        $(".book-image").attr("src","image/language.jpg");
    }
}

//查詢
$(document).ready(function(){
    $(".book-grid-search").on("input",function(){
        var book_grid=$("#book_grid").data("kendoGrid").dataSource;
        var searchString = $(".book-grid-search").val();

        book_grid.filter({field:"BookName",operator:"contains",value:searchString});
    })
})

//新增  如輸入錯誤或為空 需另外處理 其中date 可用dateinput處理
$("#button1").click(function(){
    
    num=bookDataFromLocalStorage.length;
    newnum=bookDataFromLocalStorage[num-1].BookId+1;//jsonarray找max or loop find , 名字 後大寫
    category=$("#book_category").find(':selected').text();//kendo dropdownlist 取
    name=$("#book_name").val();
    author=$("#book_author").val();
    date=kendo.toString($("#bought_datepicker").data("kendoDatePicker").value(),"yyyy-MM-dd");
    publish=$("#book_publish").val();

    
    add={
        "BookId":newnum,
        "BookCategory":category,
        "BookName":name,
        "BookAuthor":author,
        "BookBoughtDate":date,
        "BookPublisher":publish
    };
    $("#book_grid").data("kendoGrid").dataSource.add(add);
    var newdata = $("#book_grid").data("kendoGrid").dataSource.data();
    localStorage.setItem("bookData",JSON.stringify(newdata));
    window.location.reload();
})

/*
$("#button1").click(function(){
    
    num=bookDataFromLocalStorage.length;
    newnum=bookDataFromLocalStorage[num-1].BookId+1;
    category=$("#book_category").find(':selected').text();
    name=$("#book_name").val();
    author=$("#book_author").val();
    date=$("#bought_datepicker").val();
    /*datechange(date);*//*
    date=kendo.toString($("#bought_datepicker").data("kendoDatePicker").value(),"yyyy-MM-dd");
    publish=$("#book_publish").val();

    
    add={
        "BookId":newnum,
        "BookCategory":category,
        "BookName":name,
        "BookAuthor":author,
        "BookBoughtDate":date,
        "BookPublisher":publish
    };
    bookDataFromLocalStorage.push(add);
    localStorage.setItem("bookData",JSON.stringify(bookDataFromLocalStorage));
    window.location.reload();
})
*/
/*function datechange(date){
    var formattedDate = new Date(date);
    var d = formattedDate.getDate();
    var m =  formattedDate.getMonth();
    m += 1;  // JavaScript months are 0-11
    var y = formattedDate.getFullYear();

    changedate=y + "-" + m + "-" + d;
}*/


//刪除 可使用confirm 確認是否刪除
function deleteBook(e){
    var row = $(e.target).closest("tr");
    $("#book_grid").data("kendoGrid").removeRow(row);
    var newdata = $("#book_grid").data("kendoGrid").dataSource.data();
    localStorage.setItem("bookData",JSON.stringify(newdata));
   
}

/*
function deleteBook(e){
    var row = $(e.target).closest("tr");
    var rowtext=JSON.stringify(row.text())
    var i = 1;
    var num="";

    while(rowtext[i]<=10&&rowtext[i]>=0)
    {
        num+=rowtext[i];
        i++;
        
    }
    num=parseInt(num);
    i=0;
    while(num!=bookDataFromLocalStorage[i].BookId)
    {
        i++;
    }
    bookDataFromLocalStorage.splice(i,1);
    localStorage.setItem("bookData",JSON.stringify(bookDataFromLocalStorage));
    window.location.reload();
}
*/


//新視窗 可用modal遮罩
$(function(){
    var myWindow = $("#window"),
        undo = $("#undo");

    undo.click(function() {
        myWindow.data("kendoWindow").center().open();
        undo.fadeOut();
    });

    function onClose() {
        undo.fadeIn();
    }

    myWindow.kendoWindow({
        width: "600px",
        title: "book",
        visible: false,
        actions: [
            "Pin",
            "Minimize",
            "Maximize",
            "Close"
        ],
        close: onClose
    })//.data("kendoWindow").center().open();
});


//localStorage.clear();